﻿Console.OutputEncoding=System.Text.Encoding.UTF8;
MenuManagment.Menu();