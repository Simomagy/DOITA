﻿namespace Static
{
    #region Constructor and properties
    public abstract class Entity(int id)
    {
        public int Id { get; set; } = id;
    }
    #endregion
}
